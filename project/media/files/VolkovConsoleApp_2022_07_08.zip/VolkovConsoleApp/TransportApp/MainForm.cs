﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TransportApp
{
    public partial class MainForm : Form
    {
        List<Vehicle> vehicles;
        public MainForm()
        {
            InitializeComponent();
            // Список транспортных средств
            vehicles = new List<Vehicle>();
            transportMapControl.Vehicles = vehicles;
            // обновить строку состояния
            UpdateStatusBar();
        }

        private void OpenFileMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "Текстовый файл *.txt|*.txt|Все файлы|*.*";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                // Открыть файл
                if (Vehicle.ReadData(dlg.FileName, vehicles))
                {
                    // Заполнить список
                    FillListBox(vehicles, vehiclesListBox);
                    // обновить строку состояния
                    UpdateStatusBar();
                    // обновить карту
                    transportMapControl.Invalidate();
                }
            }
        }

        protected void FillListBox(List<Vehicle> vehicles, ListBox listBox)
        {
            // очистить список
            listBox.Items.Clear();

            // добавить новые элементы в список
            foreach (Vehicle v in vehicles)
                listBox.Items.Add(v);
        }

        private void SaveFileMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "Текстовый файл *.txt|*.txt|Все файлы|*.*";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                // Сохранить файл
                Vehicle.SaveData(dlg.FileName, vehicles);
            }
        }

        private void CloseMenuItem_Click(object sender, EventArgs e)
        {
            // Закрыть форму
            Close();
        }

        private void AddVehicleMenuItem_Click(object sender, EventArgs e)
        {
            // Добавление транспортного средства
            VehicleForm form = new VehicleForm();
            form.Text = "Добавление нового транспортного средства";
            if (form.ShowDialog() == DialogResult.OK)
            {
                Vehicle v = null;

                switch (form.VehicleType)
                {
                    case VehicleTypes.AirVehicle:// воздушный
                        v = new AirVehicle(
                        form.VehicleName,
                        form.MaxVolume,
                        form.IntegerValue);
                        v.Volume = form.Volume;
                        v.X = form.X;
                        v.Y = form.Y;
                        break;
                    case VehicleTypes.WaterVehicle:// водный
                        v = new WaterVehicle(
                        form.VehicleName,
                        form.MaxVolume,
                        form.DoubleValue);
                        v.Volume = form.Volume;
                        v.X = form.X;
                        v.Y = form.Y;
                        break;
                    case VehicleTypes.LandVehicle:// наземный
                        v = new LandVehicle(
                        form.VehicleName,
                        form.MaxVolume,
                        form.IntegerValue);
                        v.Volume = form.Volume;
                        v.X = form.X;
                        v.Y = form.Y;
                        break;
                }
                // добавить в список
                if (v != null)
                {
                    vehicles.Add(v);
                    vehiclesListBox.Items.Add(v);
                    // обновить строку состояния
                    UpdateStatusBar();
                    // обновить карту
                    transportMapControl.Invalidate();
                }
            }
        }

        private void EditVehicleMenuItem_Click(object sender, EventArgs e)
        {
            if (vehiclesListBox.SelectedIndex >= 0)
            {
                // Изменение транспортного средства
                VehicleForm form = new VehicleForm();
                // Режим редактирования
                form.EditMode = true;
                form.Text = "Изменение транспортного средства";
                Vehicle v = vehicles[vehiclesListBox.SelectedIndex];
                form.VehicleName = v.Name;
                form.VehicleType = v.GetVehicleType();
                form.MaxVolume = v.MaxVolume;
                form.Volume = v.Volume;
                form.X = v.X;
                form.Y = v.Y;
                // характеристика
                switch (v.GetVehicleType())
                {
                    case VehicleTypes.AirVehicle:
                        // преобразование вниз
                        form.IntegerValue = ((AirVehicle)v).Engines;
                        break;
                    case VehicleTypes.WaterVehicle:
                        form.DoubleValue = ((WaterVehicle)v).Displacement;
                        break;
                    case VehicleTypes.LandVehicle:
                        form.IntegerValue = ((LandVehicle)v).Wheels;
                        break;
                }

                if (form.ShowDialog() == DialogResult.OK)
                {
                    // новые значения полей
                    v.Name = form.VehicleName;
                    v.Volume = form.Volume;
                    v.X = form.X;
                    v.Y = form.Y;
                    // обновить список
                    vehiclesListBox.Items[
                        vehiclesListBox.SelectedIndex] = v;
                    // обновить карту
                    transportMapControl.Invalidate();
                }
            }
        }

        private void DeleteVehicleMenuItem_Click(object sender, EventArgs e)
        {
            if (vehiclesListBox.SelectedIndex >= 0)
            {
                Vehicle v = vehiclesListBox.SelectedItem as Vehicle;
                if (v != null)
                {
                    string question =
                        "Желаете удалить транспортное средство " +
                        v.Name + "?";
                    DialogResult res =
                        MessageBox.Show(question,
                        "Удаление транспортного средства",
                        MessageBoxButtons.YesNo);
                    if (res == DialogResult.Yes)
                    {
                        vehiclesListBox.Items.Remove(v);
                        vehicles.Remove(v);
                        // обновить строку состояния
                        UpdateStatusBar();
                        // обновить карту
                        transportMapControl.Invalidate();
                    }
                }
            }
        }

        private void SortAZMenuItem_Click(object sender, EventArgs e)
        {
            // Сортировка элементов по возрастанию
            if (vehicles.Count > 0)
            {
                // сортировка списка
                vehicles.Sort(Vehicle.CompareAZ);
                // обновление списка
                FillListBox(vehicles, vehiclesListBox);
            }
        }

        private void SortZAMenuItem_Click(object sender, EventArgs e)
        {
            // Сортировка элементов по возрастанию
            if (vehicles.Count > 0)
            {
                // сортировка списка
                vehicles.Sort(Vehicle.CompareZA);
                // обновление списка
                FillListBox(vehicles, vehiclesListBox);
            }
        }

        private void SelectionMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void ReportMenuItem_Click(object sender, EventArgs e)
        {

        }

        protected void UpdateStatusBar()
        {
            infoLabel.Text = "Количество транспортных средств: " +
                vehicles.Count.ToString();
        }
    }
}
