﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VolkovConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Программирование формул
            // Задача 1.            
            //Formula.Task1();

            // Задача 2.
            //Formula.Task2();

            // Задача 3
            //Formula.Task3();

            // Задача 4
            //Formula.Task4();

            // Задача 5
            //Formula.Task5();

            // Задача 6
            //Formula.Task6();

            // Задача 7
            //Formula.Task7();

            // Задача 8
            //Formula.Task8();

            // Задача 9
            //Formula.Task9();
            #endregion

            #region Программирование разветвлений
            // Задача 1
            //Selection.Task1();
            // Задача 2
            //Selection.Task2();            
            // Задача 3
            //Selection.Task3();
            #endregion

            #region Программирование циклов

            // Задача 1
            //Cycles.Task1();
            // Задача 2
            //Cycles.Task2();
            // Задача 3
            //Cycles.Task3();
            // Задача 4
            //Cycles.Task4();
            // Задача 5
            //Cycles.Task5();
            // Задача 6
            //Cycles.Task6();
            // Задача 7
            //Cycles.Task7();
            // Задача 8
            //Cycles.Task8();
            // Задача 9
            //Cycles.Task9();

            #endregion

            #region Сортировка
            // Сортировка с выбором наибольшего
            //Sort.Task1();

            // Сортировка пузырьком
            //Sort.Task2();
            #endregion

            #region Работа с файлами

            // Задача 1. Запись данных в файл
            //Files.Task1();
            // Задача 2. Чтение данных из файла
            //Files.Task2();
            // Задача 3. Ввод матрицы из файла
            //Files.Task3();

            #endregion

            #region Объектно-ориентированное программирование
            // Задача 1.
            // 
            // Задача 2.
            //OOP.Task2();
            // Самостоятельная работа 1
            OOP.S1();

            #endregion

            Console.ReadKey();
        }
    }
}
